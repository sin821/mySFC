<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../assets/jquery-1.12.4/jquery.min.js"></script>
<script src="../assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../assets/surface-win8-workaround/ie10-viewport-bug-workaround.js"></script>

<script src="../assets/datatables-1.10.12/datatables.min.js"></script>
<script>
$('body .dropdown-toggle').dropdown();
</script>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../assets/jquery-1.12.4/jquery.min.js"></script>
<script src="../assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../assets/surface-win8-workaround/ie10-viewport-bug-workaround.js"></script>
<!-- pie chart -->
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/bs-3.3.6/jqc-1.12.3/dt-1.10.12/fc-3.2.2/fh-3.1.2/r-2.1.0/datatables.min.js"></script>
<script>
$('body .dropdown-toggle').dropdown();
</script>